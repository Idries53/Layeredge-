# LayerEdge Daily Claim Bot

Automates daily faucet claims on LayerEdge.
